// increment input and return it
(function(input) {
    i = parseInt(input)
    return i+1
})(input)
